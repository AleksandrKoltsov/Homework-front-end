function sortNum(a, b){
    return (a-b);
}

console.log(sortNum(1, 2));
console.log(sortNum(3, 3));
console.log(sortNum(3, 2));