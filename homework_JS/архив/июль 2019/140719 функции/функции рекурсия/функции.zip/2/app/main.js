function nodNum(a, b){

    nod = 1;

    for(let i = a; i > 0; i--) {

        if (a % i == 0 && b % i == 0) {

            nod = i;

            break;
        }
    }
    return nod;
}

console.log(nodNum(96, 36));
console.log(nodNum(150, 35));